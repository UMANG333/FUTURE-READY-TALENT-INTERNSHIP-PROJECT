# Face-Detect-App-by--UMANG
HELLO, GUY'S- UMANG THIS SIDE AND THIS IS MY- LGMVIP INTERNSHIP TASK 3 :-  Create a face detection android app using machine learning kit (ML KIT) on firebase.
